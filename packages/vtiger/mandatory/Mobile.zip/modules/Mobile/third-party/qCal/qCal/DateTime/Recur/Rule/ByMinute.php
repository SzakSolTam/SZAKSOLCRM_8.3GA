<?php
class qCal_DateTime_Recur_Rule_ByMinute extends qCal_DateTime_Recur_Rule {

	public function getRecurrences() {
	
		return array();
	
	}

}